#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")


import pymysql
import cgi, cgitb

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
form=cgi.FieldStorage()
id=form.getvalue("id")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <title>emppage</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./media/logoonly.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

    <style>
        .nav-side-menu {
            overflow: auto;
            font-family: verdana;
            font-size: 15 px;
            font-weight: 200;
            background-image: linear-gradient(rgb(253, 9, 50), rgb(162, 4, 4), rgb(243, 3, 3));
            position: fixed;
            top: 0px;
            width: 220px;
            height: 100%;
            color: #e1ffff;

        }

        .nav-side-menu .brand {
            line-height: 50px;
            display: block;
            text-align: center;
            font-size: 14px;
            padding: 15px;
        }

        .nav-side-menu .toggle-btn {
            display: none;
        }

        .nav-side-menu ul,
        .nav-side-menu li {
            list-style: none;
            padding: 0px;
            margin: 0px;
            line-height: 35px;
            cursor: pointer;

        }

        .nav-side-menu ul :not(collapsed) .arrow:before,
        .nav-side-menu li :not(collapsed) .arrow:before {
            font-family: FontAwesome;
            content: "\f078";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;

        }

        .nav-side-menu ul .active,
        .nav-side-menu li .active {
            border-left: 3px solid #d19b3d;

        }

        .nav-side-menu ul .sub-menu li:before,
        .nav-side-menu li .sub-menu li:before {
            font-family: FontAwesome;
            content: "\f105";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
        }

        .nav-side-menu li {
            padding-left: 0px;
            border-left: 3px solid #2e353d;
            border-bottom: 3px solid white;
        }

        .nav-side-menu li a {
            text-decoration: none;
            color: #e1ffff;
            padding: 5px;
            font-size: 15px;

        }

        .nav-side-menu li:hover {
            border-left: 3px solid #d19b3d;
            background-color: deeppink;
            color: white;
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        @media (max-width: 767px) {
            .nav-side-menu {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }

            .nav-side-menu .toggle-btn {
                display: block;
                cursor: pointer;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 10 !important;
                padding: 3px;
                background-color: #ffffff;
                color: black;
                width: 40px;
                text-align: center;
            }

            .brand {
                padding-left: 5px;
                height: 100px;
            }
        }

        @media (min-width: 767px) {
            .nav-side-menu .menu-list .menu-content {
                display: block;
            }
        }

        body {
            margin: 0px;
            padding: 0px;
        }

        hr {
            color: #23282e;
            width: 120px;
        }
    </style>
</head>

<body>
    <div class="nav-side-menu">
        <div class="brand">
            <h3>User Page</h3>

        </div>
        <hr>
        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">""")
print("""
                <li>
                    <a href="./User_profile.py?id=%s"><i class="fa fa-user fa-lg"></i> Profile
                    </a>
                </li>"""%id)
print("""

                <li data-toggle="collapse" data-target="#new" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Buy A Car<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                    <li><a href="./User_buy_page.py?id=%s">Buy cars</a></li>
                    <li><a href="./User_buy_status.py?id=%s">Status</a></li>
                    <li><a href="./user_buy_user_testdrive.py?id=%s">buy Testdrive</a></li>
                </ul>"""%(id,id,id))
print("""
                <li data-toggle="collapse" data-target="#new1" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Sale A Car<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new1">
                    <li><a href="./User_sale_page.py?id=%s">Register Cars</a></li>
                    <li><a href="./User_sale_status.py?id=%s">Status</a></li>
                    <li><a href="./user_sale_testdrive.py?id=%s">Sale Testdrive</a></li>
                </ul>"""%(id,id,id))
print("""
                <li>
                    <a href="./Index_page.py">
                        <i class="fa fa-sign-out fa-lg"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>


""")
q4 = """select * from buycaruser where id='%s' """ %(id)
cur.execute(q4)
res = cur.fetchall()
for i in res:
    print("""<style>
        .card {
            border: 1px;
            background-color: white;
            border-radius: 15px 15px 15px 15px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            height: 500px;
            width: 450px;


        }

        #input {
            width: 300px;
        }
    </style>
</head>

    <br><br>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="content">
            <div class="col-md-4"></div>
            <div class="col-md-3">

                <div class="card"><br>
                    <center>
                        <h1
                            style="text-shadow: 2px 3px 2px aqua;font-family:fantasy;color: rgb(251, 83, 22);letter-spacing: 1px;">
                            BOOK a Test Drive
                        </h1>


                        <div class="form-content">
                            <div class="row">

                                <h4>complete the form below and an we will contact you to arrange your test
                                    drive
                                </h4>

                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" id="input" value="%s" name="name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Phone No" id="input" value="%s" name="pno">
                                </div>"""%(i[1],i[2]))
print("""
                                <h3>Preferred date and time of Test Drive</h3><br>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='date')"
                                        placeholder="Date" id="input" name="datee">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='time')"
                                        placeholder="Time" id="input" name="timee">
                                </div>

                                <input type="submit" class="btn-primary" value="SUBMIT" style="font-size: 20px;" name="submit">



                            </div>
                        </div>
                    </center>
                </div>

            </div>
        </div>



    </form>

""")
# q="""create table buytestdrive(id int(50) Auto_increment primary key,name varchar(50),phone_no varchar(50),date varchar(50),time varchar(50),status varchar(50))"""
# cur.execute(q)
submit=form.getvalue("submit")
if submit!=None:
    if len(form) != 0:
        name=form.getvalue("name")
        pno=form.getvalue("pno")
        datee=form.getvalue("datee")
        timee=form.getvalue("timee")
        status="New"
        q="""insert into buytestdrive(name,phone_no,date,time,status)values('%s','%s','%s','%s','%s')"""%(name,pno,datee,timee,status)
        cur.execute(q)
        print("""<script>alert("submit success");</script>""")
print("""</body>

</html>""")
conn.commit()
conn.close()