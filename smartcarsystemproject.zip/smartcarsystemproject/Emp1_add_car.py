#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")


import pymysql
import cgi, cgitb, os

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
f = cgi.FieldStorage()
id=f.getvalue("id")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <title>emppage</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./media/logoonly.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

    <style>
        .nav-side-menu {
            overflow: auto;
            font-family: verdana;
            font-size: 15 px;
            font-weight: 200;
            background-image: linear-gradient(rgb(44, 44, 165), rgb(10, 10, 162), rgb(114, 114, 229));
            position: fixed;
            top: 0px;
            width: 280px;
            height: 100%;
            color: #e1ffff;

        }

        .nav-side-menu .brand {
            line-height: 50px;
            display: block;
            text-align: center;
            font-size: 14px;
            padding: 15px;
        }

        .nav-side-menu .toggle-btn {
            display: none;
        }

        .nav-side-menu ul,
        .nav-side-menu li {
            list-style: none;
            padding: 0px;
            margin: 0px;
            line-height: 35px;
            cursor: pointer;

        }

        .nav-side-menu ul :not(collapsed) .arrow:before,
        .nav-side-menu li :not(collapsed) .arrow:before {
            font-family: FontAwesome;
            content: "\f078";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
            /* float: right; */
        }

        */ .nav-side-menu ul .active,
        .nav-side-menu li .active {
            border-left: 3px solid #d19b3d;
        }

        .nav-side-menu ul .sub-menu li,
        .nav-side-menu li .sub-menu li {
            background-color: deeppink;
            border: none;
            line-height: 28px;
            border-bottom: 1px solid #23282e;
            margin-left: 0px;
        }

        .nav-side-menu ul .sub-menu li:hover,
        .nav-side-menu li .sub-menu li:hover {
            background-color: rgb(8, 128, 248);
        }

        .nav-side-menu ul .sub-menu li:before,
        .nav-side-menu li .sub-menu li:before {
            font-family: FontAwesome;
            content: "\f105";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
        }

        .nav-side-menu li {
            padding-left: 0px;
            border-left: 3px solid #2e353d;
            border-bottom: 1px solid #23282e;
        }

        .nav-side-menu li a {
            text-decoration: none;
            color: #e1ffff;
        }

        .nav-side-menu li a i {
            padding-left: 10px;
            width: 20px;
            padding-right: 20px;
        }

        .nav-side-menu li:hover {
            border-left: 3px solid #d19b3d;
            background-color: deeppink;
            color: white;
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        @media (max-width: 767px) {
            .nav-side-menu {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }

            .nav-side-menu .toggle-btn {
                display: block;
                cursor: pointer;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 10 !important;
                padding: 3px;
                background-color: #ffffff;
                color: black;
                width: 40px;
                text-align: center;
            }

            .brand {
                padding-left: 5px;
                height: 100px;
            }
        }

        @media (min-width: 767px) {
            .nav-side-menu .menu-list .menu-content {
                display: block;
            }
        }

        body {
            margin: 0px;
            padding: 0px;
        }

        hr {
            color: #23282e;
            width: 120px;
        }

        input:hover {
            background-color: rgb(55, 253, 253);
        }

        select:hover {
            background-color: rgb(55, 253, 253);
        }



        .cc {
            background-image: linear-gradient(aqua, rgb(146, 244, 244), rgb(3, 120, 120));
            padding: 20px;
            color: deeppink;
            text-shadow: 2px 3px 2px rgb(37, 37, 245);
            font-family: fantasy;
        }
    </style>
</head>

<body>
    <div class="nav-side-menu">
        <div class="brand">
            <h1>Employee Page</h1>
            <h4>Sales Executive</h4>
        </div>
        <hr>
        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">""")
print("""
                <li>
                    <a href="./Emp1_profile.py?id=%s"><i class="fa fa-user fa-lg"></i> Profile
                    </a>
                </li>""" % id)
print("""
                <li data-toggle="collapse" data-target="#new1" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Cars<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new1">
                    <li><a href="./Emp1_add_car.py?id=%s">Add Cars</a></li>

                </ul>"""%id)
print("""
                <li data-toggle="collapse" data-target="#new" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> User Request<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                    <li><a href="./Emp1_user_buy.py?id=%s">Buy</a></li>
                    <li><a href="./Emp1_buy_testdrive.py?id=%s"> buy testdrive request</a></li>
                    <li><a href="./Emp1_user_sale.py?id=%s">Sale</a></li>
                    <li><a href="./Emp1_user_testdrive.py?id=%s">  User Testdrive approved</a></li>
                </ul>"""%(id,id,id,id))
print("""
                <li data-toggle="collapse" data-target="#service" class="collapsed">
                    <a href="./Emp1_leave_request.py?id=%s"><i class="fa fa-reply fa-lg"></i> Leave Request</a>
                </li>""" % id)
print("""
                <li>
                    <a href="./Index_page.py">
                        <i class="fa fa-sign-out fa-lg"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="container">
            <div class="content">
                <div class="col-md-3"></div>
                <div class="col-md-8">
                    <center>
                        <h1 class="cc"> <i class="fa fa-car fa-lg"></i> Car
                            Registration
                        </h1>
                    </center>
                    <br><br>
                    <div class="form-content">
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="ID Number" name="id">
                                </div>
                                <div class="form-group">
                                    <select class="form-control" id="makeSel" name="make">
                                        <option selected="selected">Make</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" id="modelSel" name="model">
                                        <option selected="selected">Model</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="trm">
                                        <option>Transmission</option>
                                        <option>Manual</option>
                                        <option>Automatic</option>
                                        <option>Continuously variable</option>
                                        <option>Semi-automatic and dual-clutch</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="year">
                                        <option>Year</option>
                                        <option>2018</option>
                                        <option>2019</option>
                                        <option>2020</option>
                                        <option>2021</option>
                                        <option>2022</option>
                                        <option>2023</option>
                                        <option>2024</option>
                                        <option>2025</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="mileage">
                                        <option>Mileage</option>
                                        <option>Volvo XC90 Petrol 42 kmpl
                                        </option>
                                        <option>Honda Amaze Diesel MT 27.4 kmpl</option>
                                        <option>Honda Jazz MT Diesel 27.3 kmpl</option>
                                        <option>Maruti Alto K10 24.9 kmpl
                                        </option>
                                        <option>Volvo XC40 14.4 kmpl</option>
                                        <option>Hyundai Grand i10 Nios CNG  28 km/l
                                            Hyundai Grand i10 Nios Diesel</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="bt">
                                        <option>Body Type</option>
                                        <option>Suv</option>
                                        <option>Coupe</option>
                                        <option>Sedan</option>
                                        <option>Mpv</option>
                                        <option>Crossovers</option>
                                        <option>Pickup</option>
                                        <option>Convertible</option>
                                        <option>Minicar</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="color">
                                        <option>Color</option>
                                        <option>Red</option>
                                        <option>Green</option>
                                        <option>Blue</option>
                                        <option>Yellow</option>
                                         <option>Black</option> 
                                         <option>White</option>
                                         
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="kd">
                                        <option>Kilometers Driven</option>
                                        <option>1000-2000 km</option>
                                        <option>2000-3000 km</option>
                                        <option>3000-4000 km</option>
                                        <option>4000-5000 km</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">

                                <div class="form-group">
                                    <select class="form-control" name="co">
                                        <option>Car Owner</option>
                                        <option>1st Owner</option>
                                        <option>2st Owner</option>
                                        <option>3st Owner</option>
                                        <option>4st Owner</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="ft">
                                        <option>Fuel Type</option>
                                        <option>Diesel</option>
                                        <option>Electric</option>
                                        <option>LPG</option>
                                        <option>Petrol</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <select class="form-control" name="st">
                                        <option>Seating Type</option>
                                        <option>4</option>
                                        <option>5</option>
                                        <option>6</option>
                                        <option>7</option>
                                        <option>8</option>
                                        <option>9</option>
                                        <option>10</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='file')"
                                        placeholder="Upload Car1 photo" required name="p1">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='file')"
                                        placeholder="Upload Car2 photo" required name="p2">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='file')"
                                        placeholder="Upload Car3 photo" required name="p3">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='file')"
                                        placeholder="Upload Car4 photo" required name="p4">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" onfocus="(this.type='file')"
                                        placeholder="Rc book Upload" required name="rc">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <center><input type="submit" value="submit" class="btn-success">
            <input type="reset" class="btn-success" style="margin-left: 20px;">
        </center>
    </form>
    <br><br>
    <script>
        var stateObject = {
            "BMW": ["BMW x6", "BMW x3", "BMW x4", "BMW 5 series", "BMW x5"],
            "Toyota": ["Avalon", "Belta", "bz 3", "Camry", "Corolla"],
            "Honda": ["Honda CR-v", "Honda pilot", "Honda Crosstour"],
            "Audi": ["A1", "A3", "Q2", "R8"],
            "KTM": [""],
            "MG": [""],
            "Tata": [""]
        }
        window.onload = function () {
            var makeSel = document.getElementById("makeSel"),
                modelSel = document.getElementById("modelSel");
            for (var make in stateObject) {
                makeSel.options[makeSel.options.length] = new Option(make, make);
            }

            makeSel.onchange = function () {
                modelSel.length = 1;
                if (this.selectedIndex < 1) return;
                var model = stateObject[this.value];
                for (var i = 0; i < model.length; i++) {
                    modelSel.options[modelSel.options.length] = new Option(model[i], model[i]);
                }
            }

        }
    </script>
</body>

</html>""")

# q="""create database project"""
# q = """create table empaddedcar(id int(50) Auto_increment primary key,id_no varchar(50),make varchar(50),model varchar(50),transmission varchar(50),year varchar(50),mileage varchar(50),body_type varchar(50),color varchar(50),kilometer_driven varchar(50),car_owner varchar(50),fuel_type varchar(50),seating_type varchar(50),car1_photo varchar(50),car2_photo varchar(50),car3_photo varchar(50),car4_photo varchar(50),rc_book_photo varchar(50))"""
# cur.execute(q)

if len(f) != 0:
    id1 = f.getvalue("id")
    make = f.getvalue("make")
    model = f.getvalue("model")
    trm = f.getvalue("trm")
    year = f.getvalue("year")
    mileage = f.getvalue("mileage")
    body = f.getvalue("bt")
    color = f.getvalue("color")
    kilometer = f.getvalue("kd")
    owner = f.getvalue("co")
    fuel= f.getvalue("ft")
    seating = f.getvalue("st")
    photo1=f['p1']
    photo2=f['p2']
    photo3=f['p3']
    photo4=f['p4']
    rc=f['rc']



    if photo1.filename:
        fn1 = os.path.basename(photo1.filename)
        fn2 = os.path.basename(photo2.filename)
        fn3 = os.path.basename(photo3.filename)
        fn4 = os.path.basename(photo4.filename)
        fn5 = os.path.basename(rc.filename)
        open("cars/" + fn1, "wb").write(photo1.file.read())
        open("cars/" + fn2, "wb").write(photo2.file.read())
        open("cars/" + fn3, "wb").write(photo3.file.read())
        open("cars/" + fn4, "wb").write(photo4.file.read())
        open("cars/" + fn5, "wb").write(rc.file.read())
        q = """insert into empaddedcar(id_no,make,model,transmission,year,mileage,body_type,color,kilometer_driven,car_owner,fuel_type,seating_type,car1_photo,car2_photo,car3_photo,car4_photo,rc_book_photo)values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')""" % (id1, make, model, trm, year,mileage, body, color, kilometer, owner, fuel, seating, fn1, fn2,fn3,fn4,fn5)
        cur.execute(q)
        print("""<script>alert("car added successfully")</script>""")

conn.commit()
conn.close()
