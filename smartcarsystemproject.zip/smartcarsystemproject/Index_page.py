#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>homepage</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        a {
            color: white;
            font-size: 20px;
        }



        .logo {
            height: 45px;
            width: 45px;
        }

        article {
            margin-top: 100px;
        }

        #buy1 {
            font-size: 18px;

        }

        #buy2 {
            font-size: 18px;
        }

        .buy {
            margin-left: 100px;
            margin-top: -150px;

        }

        .ab {
            font-size: 40px;
            margin-left: -110px;
        }

       footer {
            background-color: black;
            height: 160px;
            color: white;
            font-size: 15px;
        }


        .p {
            margin-top: -34px;
            color: white;
            margin-left: 50px;
            font-size: 30px;
        }

        .centered {
            position: absolute;
            top: 40%;
            left: 45%;
            transform: translate(-50%, -50%);
            color: white;
            margin-left: 50px;
        }

        .h1 {
            font-size: 45px;
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
            text-shadow: 3px 3px 3px blue;
            letter-spacing: 2px;
            margin-top: -130px;
        }

        .i {
            font-size: 18px;

        }

        #color {
            opacity: 0.9;
            background-color: ghostwhite;

        }

        #name {
            border: 1px solid black;
        }

        #name1 {
            border: 1px solid black;
        }

        #name2 {
            border: 1px solid black;
        }

        #password {
            border: 1px solid black;
        }

        #password1 {
            border: 1px solid black;
        }

        #password2 {
            border: 1px solid black;
        }

        form {
            width: 300px;
            height: 300px;
        }

        .a {
            color: black;
            font-size: 15px;
            margin-left: -180px;
        }

        .aa {
            color: black;
            font-size: 15px;
        }

        #log {
            font-size: 35px;
        }

        .form {
            height: 200px;

        }

        #form {
            height: 250px;
        }

        .btoggle {
            margin-left: 260px;
            margin-top: -30px;
        }
        .card {
            background-color: white;
            border-radius: 10px;
            width: 80%;
            border-radius: 10px;
            box-shadow: 0px 0px 5px black;
            border: 1px;
        }
        #myBtn {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 30px;
            
            font-size: 20px;
            border: none;
            outline: none;
            background-color: white;
            color: black;
            cursor: pointer;
            padding: 5px;
            border-radius: 100px;
        }

    </style>
</head>

<body>
    <header>

        <nav class="navbar navbar-inverse  navbar-fixed-top">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-target="#add" data-toggle="collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="#" class="navbar-brand">
                    <img src="./media/logo-removebg-preview.png" alt="" class="logo">
                    <p class="p">24/7 Used Cars sales & buy</p>
                </a>

            </div>

            <div class="collapse  navbar-collapse" id="add">

                <ul class="nav navbar-nav navbar-right ">
                    <li class="dropdown">
                    <li id="s"><a href="./Car_page.py"
                            style="color:white;font-size: 30px;border: 1px solid;border-radius: 20px;margin-top: 2px;">Cars</a>
                    </li>
                    <li><a href="" class="dropdown-toggle" data-toggle="dropdown">Employee Login<span
                                class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#" data-toggle="modal" data-target="#employee">Employee Login</a></li>
                            <li><a href="#" data-toggle="modal" data-target="#admin">Admin Login</a></li>
                        </ul>
                    </li>
                    <li><a href="#" data-toggle="modal" data-target="#mymodal"><span
                                class="glyphicon glyphicon-log-in"></span> User Login</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <section>
        <center>
            <div>
                <div id="mycarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="mycarousel" data-slide-to="0" class="active"></li>
                        <li data-target="mycarousel" data-slide-to="1"></li>
                        <li data-target="mycarousel" data-slide-to="2"></li>
                        <li data-target="mycarousel" data-slide-to="3"></li>

                    </ol>
                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="./media/car1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./media/c6.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="./media/c10.jpg" alt="">
                        </div>

                        <div class="item">
                            <img src="./media/c8.jpg" alt="">
                        </div>
                        
                    </div>
                    <a href="#mycarousel" class="left carousel-control" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a href="#mycarousel" class="right carousel-control" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>

                </div>
            </div>
        </center>

        <div class="centered">
            <center>
                <h1 class="h1">Smart Car System</h1>
            </center>
            <i class="i">
                <center><b>Find Your Dream Car</b></center>
            </i>
        </div>
    </section>
    <br><br><br><br><br>
    <article>
        <div class="buy">
            <center class="ab"><b>ABOUT US</b></center>
            <div class="col-md-6" id="buy1">
             <div class="card">
             <center>
                <hr align="left" width="1px">
                <b class="b">BUY A CAR</b><br>
                <br>
                
                <i>we sell perspiciatis unde omnis iste natus<br> error sit voluptatem accusantiumn <br>doloremque
                    laudantium</i></center>
                    
             </div>
            </div>
            <div class="col-md-6" id="buy2">
             <div class="card">
                <hr align="left" width="1px">
                <center>
                <b class="b">SELL MY CAR</b><br>
                <br>
                <i>you can sell sed ut unde omnis iste natus<br>error sit voluptatem accusantiumn<br>doloremque
                    laudantium</i></center>
             </div>
            </div>
        </div>
    </article>
    <br><br><br><br>
    <div>
        <center><img src="./media/1677736257930.jpg" alt="" width="100%"></center>
    </div><br><br><br>

    <footer>
        <div class="container">
            <center>
                <h3>contact info</h3>
                <hr color="red" width="70px" align="center">
            </center>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-map-marker"></span>
                24 New street,coimbatore
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-earphone"></span> <a href="tel:1234567890" style="font-size: 15px;"> +1234567890</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-envelope"></span><a href="mailto:car24@email.com" style="font-size: 15px;">
                    car24@email.com</a>
            </div>

        </div><br>
    </footer>
    <center>
        <div class="modal" id="mymodal">
            <div class="modal-dialog">
                <div class="modal-content" id="color">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title" id="log">
                            <center><span class="glyphicon glyphicon-user"></span> User Login</center>
                        </h3>
                        <br><br><br>
                        <form action="" autocomplete="off">
                            <div>
                                <input type="text" class="form-control" id="name" placeholder="UserName" name="uname">
                                <br>
                                <input type="password" class="form-control" id="password" placeholder="Password"
                                    name="password1">
                                <div class="btoggle"> <button type="button" class="toggle" id="btoggle"><span
                                            class="glyphicon glyphicon-eye-open" id="eyeicon"></span></button></div><br>
                                <a href="#" class="a" data-toggle="modal" data-target="#forgot">Forget
                                    password?</a><br><br><br>

                                <input type="submit" class="btn btn-success" value="Submit"  name="ulogin">                                <br><br><br>
                                <center><a href="./User_Register.py" class="aa">New user click here to Register</a>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>

    <center>
        <div class="modal" id="admin">
            <div class="modal-dialog">
                <div class="modal-content" style="background-color: darkturquoise; opacity: 0.9;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title" id="log">
                            <center><span class="glyphicon glyphicon-user"></span> Admin Login</center>
                        </h3>
                        <br><br><br>
                        <form action="./Admin_page.py"  onsubmit="return Admin()" autocomplete="off" class="form">
                            <div>
                                <input type="text" class="form-control" id="name2" placeholder="UserName"><br>
                                <input type="password" class="form-control" id="password2" placeholder="Password">
                                <div style="margin-left: 160px;"> <input type="checkbox" onclick="my()">Show
                                    Password</div>

                                <br>
                                <br>
                                <button type="submit"  
                                     value="login">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>
    <script>
        function Admin() {
            var name = document.getElementById("name2").value;
            var password = document.getElementById("password2").value;
            if (name == "" && password == "") {
                alert("please enter your name");
                return false;
            }
            else if (name == "Admin" && password == "Admin123") {
                alert("Login successful");
                return true;
            }
            else {
                alert("Login failed");
                return false;
            }
        }
    </script>
    <center>
        <div class="modal" id="employee">
            <div class="modal-dialog">
                <div class="modal-content" style="background-color:moccasin; opacity: 0.8;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title" id="log">
                            <center><span class="glyphicon glyphicon-user"></span> Employee Login</center>
                        </h3>
                        <br><br><br>
                        <form action="" autocomplete="off" id="form">
                            <div>
                                <input type="text" class="form-control" id="name1" name="ename" placeholder="UserName"><br>
                                <input type="password" class="form-control" id="password1" name="password2" placeholder="Password" >
                                <div style="margin-left: 160px;"> <input type="checkbox" onclick="myFunction()">Show
                                    Password</div>


                                <br>
                                <a href="#" class="a" data-toggle="modal" data-target="#eforgot">Forget
                                    password?</a><br>
                                <br>
                                <button type="submit" class="btn btn-primary"  Value="submit" name="esubmit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>

    <center>
        <div class="modal" id="forgot" style="height: 450px;">
            <div class="modal-dialog">
                <div class="modal-content" style="background-color: white;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <center><br><br>
                            <h1 class="modal-title"> Forget Password ?
                            </h1><br>
                            <div style="color: black; font-size: 15px; margin-left: -10px;">Enter your email to reset
                                your
                                password.</div>
                            <br><br><br>
                            <form action="" autocomplete="off" method="post"  enctype="multipart/form-data">
                                <div id="center">
                                    <input type="email" class="form-control" id="email" placeholder="Email@id" name="email1">
                                    <br><br>
                                    <input type="submit" class="btn btn-success" value="submit" name="submit1">
                                </div>
                            </form>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </center>
   
     <center>
        <div class="modal" id="eforgot" style="height: 450px;">
            <div class="modal-dialog">
                <div class="modal-content" style="background-color: white;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <center><br><br>
                            <h1 class="modal-title"> Forget Password ?
                            </h1><br>
                            <div style="color: black; font-size: 15px; margin-left: -10px;">Enter your email to reset
                                your
                                password.</div>
                            <br><br><br>
                            <form action="" autocomplete="off">
                                <div id="center">
                                    <input type="email" class="form-control" id="email" placeholder="Email@id" name="email2">
                                    <br><br>
                                    <input type="submit"  class="btn btn-primary" value="submit" name="submit2">
                                </div>
                            </form>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </center>
<script>
        let passwordInput = document.getElementById('password'),
            toggle = document.getElementById('btoggle')
        icon = document.getElementById('eyeicon');
        function togglePassword() {
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.classList.add("glyphicon-eye-close");

            } else {
                passwordInput.type = "password";
                icon.classList.remove("glyphicon-eye-close")

            }
        }
        function checkInput() {

        }
        toggle.addEventListener('click', togglePassword, false);
        passwordInput.addEventListener('keyup', checkInput, false);

    </script>

    <script>
        function myFunction() {
            var x = document.getElementById('password1');
            if (x.type === "password") {
                x.type = "text";

            } else {
                x.type = "password";

            }

        }
    </script>
    <script>
        function my() {
            var x = document.getElementById('password2');
            if (x.type === "password") {
                x.type = "text";

            } else {
                x.type = "password";

            }

        }
    </script>
     <button onclick="topFunction()" id="myBtn"><span class="glyphicon glyphicon-circle-arrow-up"></span></button>

    <script>

        let mybutton = document.getElementById("myBtn");

        window.onscroll = function () { scrollFunction() };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
</body>

</html>""")
import pymysql
import cgi, cgitb
cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
form=cgi.FieldStorage()
name=form.getvalue("uname")
password=form.getvalue("password1")
submit=form.getvalue("ulogin")
# print(form)
# Reg=form.getvalue("submit")
# if Reg!=None:
if submit != None:
    q = """select id from uregister where username='%s' and password='%s' """ % (name,password)
    cur.execute(q)
    res=cur.fetchone()
    if res!=None:
        print("""<script>alert("login successfully");location.href="./User_login_page.py?id=%s";</script>"""%res[0])
    else:
        print("""<script>alert("login failed");</script>""")


namee=form.getvalue("ename")
passwordd=form.getvalue("password2")
submit=form.getvalue("esubmit")
# print(form)
if submit != None:
    q1 = """select id from empregister where username='%s' and password='%s' and destination='Sales Executive' """ % (namee,passwordd)
    cur.execute(q1)
    res = cur.fetchone()
    q8 = """select id from empregister where username='%s' and password='%s' and destination='Mechanical' """ % (namee, passwordd)
    cur.execute(q8)
    res1=cur.fetchone()
    if res!=None:
        print("""<script>alert("login successfully");
        location.href="./Emp1_page_SE.py?id=%s";</script>"""%res[0])
    if res1 != None:
        print("""<script>alert("login successfully");
           location.href="./Emp2_page_MECH.py?id=%s";</script>""" %res1[0])
    else:
        print("""<script>alert("Enter your valid data")</script>""")



uemail1=form.getvalue("email1")
submit1=form.getvalue("submit1")
if submit1 != None:
    q2="""select Id from uregister where email='%s' """ %(uemail1)
    cur.execute(q2)
    idvalue=cur.fetchone()
    q3="""select * from uregister where id=%s """ %(idvalue)
    cur.execute(q3)
    rec=cur.fetchall()
    for i in rec:
        Name = i[1]
        email4 = i[2]
        username2 = i[4]
        password2 = i[5]
        contact = i[6]
        photo = i[10]
        status="New"

        # print(Name)
        q4="""insert into userforget(name,email,username,password,contact_no,upload_photo,status)values('%s','%s','%s','%s','%s','%s','%s')""" % (Name,email4,username2,password2,contact,photo,status)
        cur.execute(q4)
        print("""<script>alert("request submit success");</script>""")
    else:
        print("""<script>alert("Enter your valid data");</script>""")



eemail1=form.getvalue("email2")
submit2=form.getvalue("submit2")
if submit2 != None:
    q5="""select Id from empregister where email='%s' """ %(eemail1)
    cur.execute(q5)
    id1value=cur.fetchone()
    q6="""select * from empregister where id=%s """ %(id1value)
    cur.execute(q6)
    rec=cur.fetchall()
    for i in rec:
        idno=i[1]
        Name1 = i[2]
        email5 = i[3]
        des=i[7]
        username3 = i[20]
        password3 = i[21]
        contact1 = i[8]
        photo1 = i[12]
        Status="New"

        # print(Name)
        q7="""insert into eforget(id_number,name,email,destination,username,password,contact_no,upload_photo,status)values('%s','%s','%s','%s','%s','%s','%s','%s','%s')""" % (idno,Name1,email5,des,username3,password3,contact1,photo1,Status)
        cur.execute(q7)
        print("""<script>alert("request submit success");</script>""")
    else:
        print("""<script>alert("Enter your valid data");</script>""")


conn.commit()
conn.close()
