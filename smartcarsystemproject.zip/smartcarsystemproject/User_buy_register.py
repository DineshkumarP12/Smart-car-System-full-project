#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")


import pymysql
import cgi, cgitb, os

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
f = cgi.FieldStorage()
pid = f.getvalue("id")
idvalue=f.getvalue("id")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./media/logoonly.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <style>
        .nav-side-menu {
            overflow: auto;
            font-family: verdana;
            font-size: 15 px;
            font-weight: 200;
            background-image: linear-gradient(rgb(253, 9, 50), rgb(162, 4, 4), rgb(243, 3, 3));
            position: fixed;
            top: 0px;
            width: 220px;
            height: 100%;
            color: #e1ffff;

        }

        .nav-side-menu .brand {
            line-height: 50px;
            display: block;
            text-align: center;
            font-size: 14px;
            padding: 15px;
        }

        .nav-side-menu .toggle-btn {
            display: none;
        }

        .nav-side-menu ul,
        .nav-side-menu li {
            list-style: none;
            padding: 0px;
            margin: 0px;
            line-height: 35px;
            cursor: pointer;

        }

        .nav-side-menu ul :not(collapsed) .arrow:before,
        .nav-side-menu li :not(collapsed) .arrow:before {
            font-family: FontAwesome;
            content: "\f078";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;

        }

        .nav-side-menu ul .active,
        .nav-side-menu li .active {
            border-left: 3px solid #d19b3d;

        }

        .nav-side-menu ul .sub-menu li:before,
        .nav-side-menu li .sub-menu li:before {
            font-family: FontAwesome;
            content: "\f105";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
        }

        .nav-side-menu li {
            padding-left: 0px;
            border-left: 3px solid #2e353d;
            border-bottom: 3px solid white;
        }

        .nav-side-menu li a {
            text-decoration: none;
            color: #e1ffff;
            padding: 5px;
            font-size: 15px;

        }

        .nav-side-menu li:hover {
            border-left: 3px solid #d19b3d;
            background-color: deeppink;
            color: white;
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        @media (max-width: 767px) {
            .nav-side-menu {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }

            .nav-side-menu .toggle-btn {
                display: block;
                cursor: pointer;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 10 !important;
                padding: 3px;
                background-color: #ffffff;
                color: black;
                width: 40px;
                text-align: center;
            }

            .brand {
                padding-left: 5px;
                height: 100px;
            }
        }

        @media (min-width: 767px) {
            .nav-side-menu .menu-list .menu-content {
                display: block;
            }
        }

        body {
            margin: 0px;
            padding: 0px;
        }

        hr {
            color: #23282e;
            width: 120px;
        }
    </style>
</head>

<body>
    <div class="nav-side-menu">
        <div class="brand">
            <h3>User Page</h3>

        </div>
        <hr>
        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">""")
print("""
                <li>
                    <a href="./User_profile.py?id=%s"><i class="fa fa-user fa-lg"></i> Profile
                    </a>
                </li>
"""%pid)
print("""

                <li data-toggle="collapse" data-target="#new" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Buy A Car<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                    <li><a href="./User_buy_page.py?id=%s">Buy cars</a></li>
                    <li><a href="./User_buy_status.py?id=%s">Status</a></li>
                    <li><a href="./user_buy_user_testdrive.py?id=%s">buy Testdrive</a></li>
                </ul>"""%(pid,pid,pid))
print("""
                <li data-toggle="collapse" data-target="#new1" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Sale A Car<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new1">
                    <li><a href="./User_sale_page.py?id=%s">Register Cars</a></li>
                    <li><a href="./User_sale_status.py?id=%s">Status</a></li>
                    <li><a href="./user_sale_testdrive.py?id=%s">Sale Testdrive</a></li>
                </ul>"""%(pid,pid,pid))
print("""
                <li>
                    <a href="./Index_page.py">
                        <i class="fa fa-sign-out fa-lg"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <br><br>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="content">
            <div class="col-md-2"></div>
            <div class="form">
                <center>
                    <h1
                        style="text-shadow: 2px 3px 2px aqua;font-family:fantasy;color: rgb(13, 108, 108);letter-spacing: 1px;">
                        Register Now
                    </h1>

                    <br>

                    <div class="form-content">
                        <div class="row">
                            <div class="col-md-5"></div>
                            <div class="col-md-4">

                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Date of sale" name="date1"  onfocus="(this.type='date')">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Current Location" name="location">
                                </div>
                                
                                
                                <div class="form-group">
                                    <select class="form-control" name="pmethod">
                                        <option>Payment method</option>
                                        <option>Cash On Delivery</option>
                                        <option>Online</option>
                                    </select>
                                </div>
                                 <input type="submit" class="btn-success" value="Submit" style="font-size: 20px;" name="submit">


                                                        </div>

                        </div>
                    </div>
                </center>
            </div>

        </div>

        </div>
""")

q2= """select * from uregister where id='%s' """ %(pid)
cur.execute(q2)
res=cur.fetchall()
for i in res:
    print("""
                        <div>
                            <input type="text" class="form-control hh" id="uname" placeholder="Name"  value="%s" name="name" style="display:none;"><br>
                            <input type="text" class="form-control hh" id="password" placeholder="phone number" value="%s" name="pno" style="display:none;">
                            
                        </div>
                    """%(i[1],i[7]))

q = """select * from addcars where id='%s' """ %(idvalue)
cur.execute(q)
res = cur.fetchall()
for i in res:
    fn="cars/"+i[14]
    print("""
                        <div>
                            <input type="text" class="form-control hh"  placeholder="id number"  value="%s" name="idno" style="display:none;"><br>
                            <input type="text" class="form-control hh" placeholder="make" value="%s" name="make" style="display:none;">
                            <input type="text" class="form-control hh"  placeholder="model"  value="%s" name="model" style="display:none;"><br>
                            <input type="text" class="form-control hh" placeholder="body type" value="%s" name="bt" style="display:none;">
                            <input type="text" class="form-control hh"  placeholder="fuel type"  value="%s" name="ft" style="display:none;"><br>
                            <input type="text" class="form-control hh"  placeholder="year" value="%s" name="year" style="display:none;">
                            <input type="text" class="form-control hh"  placeholder="price" value="%s" name="price" style="display:none;">
<input type="text" class="form-control hh"  placeholder="photo" value="%s" name="p1" style="display:none;">

                        </div>
                           
                    </form>"""%(i[1], i[2],i[3],i[7],i[11],i[5],i[12],fn))


submit=f.getvalue("submit")
if submit!=None:
    name = f.getvalue("name")
    phno = f.getvalue("pno")
    idno = f.getvalue("idno")
    make = f.getvalue("make")
    model = f.getvalue("model")
    bt = f.getvalue("bt")
    ft = f.getvalue("ft")
    year = f.getvalue("year")
    price = f.getvalue("price")
    photo=f.getvalue("p1")
    date1=f.getvalue("date1")
    location=f.getvalue("location")
    pmethod=f.getvalue("pmethod")
    status="New"
    q3="""insert into buycaruser(name,phone_no,date_of_sale,current_location,payment_method,id_number,make,model,body_type,fuel_type,year,price,status,photo)values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"""%(name,phno,date1,location,pmethod,idno,make,model,bt,ft,year,price,status,photo)
    cur.execute(q3)
    conn.commit()
    print("""<script>alert("submit success");</script>""")
print("""</body>

</html>""")
conn.close()