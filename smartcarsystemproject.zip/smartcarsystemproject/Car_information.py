#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car info</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .c {
            background-color: gray;

        }

        p {
            font-size: 35px;
        }


        .cl {
            margin-right: 100px;
        }

        .form-group {
            float: left;
            width: 23%;
        }

        .s {
            border: 1px;
            background-color: white;
            border-radius: 15px 15px 15px 15px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            height: 570px;

        }

        .vv {
            border-top: 4px solid red;
            width: 40px;
            margin-left: 110px;
        }

        .ss {
            border-radius: 15px 15px 15px 15px;
           
        }
       

        footer {
            background-color: black;
            height: 100px;
            color: white;
        }

        .kk {
            border: 1px;
            background-color: white;
            border-radius: 15px 15px 15px 15px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            height: 400px;
            width: 90%;

        }

        .kk:hover {
            box-shadow: 0px 0px 10px rgb(109, 211, 245);
            background-color: rgb(255, 95, 36);
        }

        .hr {
            border: 3px solid gray;
            width: 200px;
            opacity: 0.1;

        }
    </style>
</head>

<body>
    <nav class="navbar navbar-fixed-top c">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-target="#add" data-toggle="collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">
                <p style="color: white;"> <img src="./media/R-removebg-preview (2).png" alt="" class="logo" width="80px"
                        height="40px">
                    24/7</p>
            </a>

        </div>
    </nav>
    <br><br><br> <br><br><br>

    <div class="col-md-6">
        <div class="container">""")
import pymysql
import cgi, cgitb

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
f=cgi.FieldStorage()
pid = f.getvalue("id")
q2= """select * from addcars where id=%s """ % (pid)
cur.execute(q2)
res=cur.fetchall()
for i in res:
    fn="./cars/" + i[14]
    fn1="./cars/"+i[15]
    fn2 = "./cars/" + i[16]
    fn3 = "./cars/" + i[17]
    # print(fn3)
    print("""
     <img src="{}" style="width:45%" id="expandedImg" class="jj">
            <div id="imgtext"></div>
            <br>
        </div>
        <div class="col-md-12">

            <div class="row">
                <div class="form-group">
                    <img src="{}"  style="width:85%" onclick="myFunction(this);" class="ss">
                </div>
                <div class="form-group">
                    <img src="{}" style="width:85%" onclick="myFunction(this);" class="ss">
                </div>
                <div class="form-group">
                    <img src="{}" style="width:85%" onclick="myFunction(this);" class="ss">
                </div>
                <div class="form-group">
                    <img src="{}" style="width:85%" onclick="myFunction(this);" class="ss">
                </div>

""".format(fn, fn, fn1, fn2, fn3))
    print("""
             </div>
        </div>
        <hr class="hr" align="left">
        <h1>%s</h1>
        <hr class="hr" align="left">"""%(i[12]))
    print("""    
        <div style="margin-left: 410px;">
            <button class="btn-success"><a href="./User_Register.py" style="color: white;font-size: 20px;">BOOK
                    NOW</a></button>
        </div>
        <script>
            function myFunction(imgs) {
                var expandImg = document.getElementById("expandedImg");
                var imgText = document.getElementById("imgtext");
                expandImg.src = imgs.src;
                imgText.innerHTML = imgs.alt;
                expandImg.parentElement.style.display = "block";
            }
        </script>
    </div>""")
    print(""" <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="card s">
                    <br>
                     <center>
                        <h2>Vehicle Information</h2>
                        <hr class="vv">
                    </center>
                    """)

    print("""
                 <table>
                   
                        <tr>
                            <td class="col-md-2">
                                <h4>Id Number</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        <tr>
                            <td class="col-md-2">
                                <h4>Make</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        """%(i[1],i[2]))
    print("""                        <tr>
                            <td class="col-md-2">
                                <h4>Model</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        <tr>
                            <td class="col-md-2">
                                <h4>Transmission</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        <tr>
                            <td class="col-md-2">
                                <h4>Year</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        """%(i[3],i[4],i[5]))


    print("""
                        <tr>
                            <td class="col-md-2">
                                <h4>Mileage</h4>
                            </td>
                            """)
    print("""
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>
                      </tr>

    """%(i[6]))
    print("""

                        <tr>
                            <td class="col-md-2">
                                <h4>Body type</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>"""%(i[7]))
    print("""
                        <tr>
                            <td class="col-md-2">
                                <h4>color</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
   
                        <tr>
                            <td class="col-md-2">
                                <h4>KMs Drive</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>
                            </tr>"""%(i[8],i[9]))
    print("""
                        
                        <tr>
                            <td class="col-md-2">
                                <h4>Fuel type</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
                        <tr>
                            <td class="col-md-2">
                                <h4>Seating type</h4>
                            </td>
                            <td class="col-md-2">
                                <h4>%s</h4>
                            </td>

                        </tr>
    """%(i[11],i[13]))
    print("""
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br><br><br><br><br>""")
    print("""<div class="container">

        <div class="col-md-4">
            <div class="card kk">
                <br><br>
                <center>
                    <img src="./media/time-removebg-preview.png" alt="" width="70px"><br>
                    <h4><b>Fast & Easy Booking</b></h4>
                    <hr width="50">
                    <hr width="70"><br>
                    <h4>Gone are the days of spending<br> weeks to sell a car.<br> Sell your car in<br> minutes from
                        home</h4>
                </center>

            </div>
        </div>
        <div class="col-md-4">
            <div class="card kk">
                <br><br>
                <center>
                    <img src="./media/location-removebg-preview.png" alt="" width="70px"><br>
                    <h4><b>Many Pickup Location</b></h4>
                    <hr width="50">
                    <hr width="70"><br>
                    <h4> You can register as many pickup<br> locations for your <br> multiple warehouse <br>locations
                    </h4>
                </center>

            </div>
        </div>
        <div class="col-md-4">
            <div class="card kk">

                <br><br>
                <center>
                    <img src="./media/booking-removebg-preview.png" alt="" width="70px"><br>
                    <h4><b>Delivery Service</b></h4>
                    <hr width="50">
                    <hr width="70"><br>
                    <h4>We will verify the car details<br> at your home, pick <br>up the car and transfer <br>the
                        amount.
                    </h4>
                </center>

            </div>
        </div>

    </div>
    <br><br><br>
    <footer>
        <div class="container"><br><br>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-earphone"></span> <a href="tel:1234567890"> +1234567890</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-envelope"></span><a href="mailto:car24@email.com">
                    car24@email.com</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-map-marker"></span>
                24 New street, coimbatore
            </div>

        </div>
    </footer>

</body>

</html>""")
conn.commit()
conn.close()