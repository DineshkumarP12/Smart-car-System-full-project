#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .c {
            background-color: white;

        }

        p {
            font-size: 35px;
        }


        #img {
            width: 100%;
        }

        /* .blur {
            filter: blur(1px);
        } */
        .cl {
            margin-right: 100px;
        }

        .centered {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            margin-top: -210px;
        }

        .form-control {
            border-radius: 20px;
            height: 30px;
            width: 450px;
            border-color: black;
        }

        span {
            background-color: black;
        }

        .card {
            border: 1px;
            background-color: white;
            border-radius: 15px 15px 15px 15px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            height: 400px;
            width: 90%;

        }

        .card:hover {
            box-shadow: 0px 0px 10px rgb(109, 211, 245);
        }



        img {
            border-radius: 15px 15px 0 0;
        }

        #myBtn {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 30px;
            /* z-index: 99; */
            font-size: 20px;
            border: none;
            outline: none;
            background-color: black;
            color: white;
            cursor: pointer;
            padding: 10px;
            border-radius: 50px;
        }

        .bottom-right {
            position: absolute;
            bottom: 30px;
            right: 50px;

        }

        .video {
            border-radius: 50px;
            box-shadow: 0 7px 15px 0 #00000033;
            background-color: white;

        }

        .video:hover {
            box-shadow: 0px px 15px rgb(109, 211, 245);
        }

        footer {
            background-color: black;
            height: 100px;
            color: white;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-fixed-top c">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-target="#add" data-toggle="collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">
                <p> <img src="./media/R-removebg-preview (2).png" alt="" class="logo" width="80px" height="40px">
                    24/7</p>
            </a>

        </div>

       <div class="collapse  navbar-collapse" id="add">
            <ul class="nav navbar-nav navbar-right cl">
                <li class="dropdown">
               

            </ul>
        </div>
    </nav>

    <div class="blur">
        <img src="./media/24c.jpg" alt="" id="img">
    </div>
    <center>
        <div class="centered">
            <input type="search" class="form-control" placeholder="Search">
        </div>
    </center>
    <br><br>
     
    """)
import pymysql
import cgi, cgitb

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
q="""select*from addcars"""
cur.execute(q)
res=cur.fetchall()
print("""
    <div class="container">
""")
for i in res:
    fn="cars/" + i[14]
    print("""
     <a href="./Car_information.py?id=%s">"""%(i[0]))
    print("""
             <div class="col-md-4">
                <div class="card">
                   <img src='{}' alt="Avatar" style="width:100%" height="250px">
                    <br>
                    <center>
                    <h2><b> {} </b></h2>
                    <p> {} </p>
                    </center> 
               </div>
             </div>
                </a>     
                """.format(fn, i[2], i[12]))
print("""
</div>
   <br><br><br><br><br><br>
    <div class="container">
        <div class="col-md-1"></div>
        <div class="col-md-5">
            <div class="form-group">
            """)

print("""
                <video src="./media/car.mp4" width="440px" height="248px" muted autoplay loop class="video"></video>
            </div>
        </div>
        <div class="form-groups" id="sys">
            <center>
                <h2 style="font-family: fantasy;">Smart Car System</h2>
                <h3>I spent a lot of money on booze, birds and fast cars. The rest I just squandered!
                </h3>
                <h3>Find your dream car!</h3>
            </center>

        </div>
    </div>
    <br><br><br><br><br>
    <div>
        <center><img src="./media/1677736257930.jpg" alt="" width="100%"></center>
    </div>
    <br><br><br><br><br>
    <footer>
        <div class="container"><br><br>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-earphone"></span> <a href="tel:1234567890"> +1234567890</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-envelope"></span><a href="mailto:car24@email.com">
                    car24@email.com</a>
            </div>
            <div class="col-md-4">
                <span class="glyphicon glyphicon-map-marker"></span>
                24 New street, coimbatore
            </div>

        </div>
    </footer>
    <button onclick="topFunction()" id="myBtn">
        <span class="glyphicon glyphicon-circle-arrow-up" onclick="topFunction()"></span>
    </button>

    <script>

        let mybutton = document.getElementById("myBtn");

        window.onscroll = function () { scrollFunction() };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }


        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>

</body>

</html>""")
conn.commit()
conn.close()
