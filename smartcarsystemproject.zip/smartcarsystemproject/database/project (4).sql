-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2023 at 02:03 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcars`
--

CREATE TABLE `addcars` (
  `id` int(50) NOT NULL,
  `id_no` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `transmission` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `mileage` varchar(50) DEFAULT NULL,
  `body_type` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `kilometer_driven` varchar(50) DEFAULT NULL,
  `car_owner` varchar(50) DEFAULT NULL,
  `fuel_type` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `seating_type` varchar(50) DEFAULT NULL,
  `car1_photo` varchar(50) DEFAULT NULL,
  `car2_photo` varchar(50) DEFAULT NULL,
  `car3_photo` varchar(50) DEFAULT NULL,
  `car4_photo` varchar(50) DEFAULT NULL,
  `rc_book_photo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addcars`
--

INSERT INTO `addcars` (`id`, `id_no`, `make`, `model`, `transmission`, `year`, `mileage`, `body_type`, `color`, `kilometer_driven`, `car_owner`, `fuel_type`, `price`, `seating_type`, `car1_photo`, `car2_photo`, `car3_photo`, `car4_photo`, `rc_book_photo`) VALUES
(1, 'TN 09', 'Honda', 'Honda Crosstour', 'Manual', '2022', 'Honda Amaze Diesel MT 27.4 kmpl', 'Coupe', 'White', '1000-2000 km', '1st Owner', 'petrol', '4-5 Lakhs', '5', '1680105134507.jpg', '1680105134499.jpg', '1680105134491.jpg', '1680105134482.jpg', 'rcbook.jpg'),
(2, 'TN 38', 'Toyota', 'Avalon', 'Manual', '2019', 'Volvo XC90 Petrol 42 kmpl', 'Coupe', 'Red', '4000-5000 km', '1st Owner', 'Petrol', '4-5 Lakhs', '5', '1680105134415.jpg', '1680105134431.jpg', '1680105134440.jpg', '1680105134423.jpg', 'rcbook.jpg'),
(3, 'TN 38', 'Maruti', 'Dzire', 'Manual', '2020', 'Honda Amaze Diesel MT 27.4 kmpl', 'Coupe', 'Blue', '4000-5000 km', '1st Owner', 'Petrol', '7-8 Lakhs', '5', '1680105134448.jpg', '1680105134465.jpg', '1680105134474.jpg', '1680105134456.jpg', 'rcbook.jpg'),
(5, 'TN 11', 'Maruti', 'Wagon R 1.0', 'Manual', '2018', 'Maruti Alto K10 24.9 kmpl', 'Coupe', 'Gray', '4000-5000 km', '1st Owner', 'Petrol', '7-8 Lakhs', '5', '1680105134388.jpg', '1680105134400.jpg', '1680105134356.jpg', '1680105134373.jpg', 'rcbook.jpg'),
(6, 'TN 38', 'Maruti', 'Dzire', 'Manual', '2020', 'Honda Amaze Diesel MT 27.4 kmpl', 'Coupe', 'Blue', '4000-5000 km', '1st Owner', 'Petrol', '6-8 Lakhs', '5', '1680105134448.jpg', '1680105134465.jpg', '1680105134474.jpg', '1680105134456.jpg', 'rcbook.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `buycaruser`
--

CREATE TABLE `buycaruser` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `date_of_sale` varchar(50) DEFAULT NULL,
  `current_location` varchar(50) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `body_type` varchar(50) DEFAULT NULL,
  `fuel_type` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buycaruser`
--

INSERT INTO `buycaruser` (`id`, `name`, `phone_no`, `date_of_sale`, `current_location`, `payment_method`, `id_number`, `make`, `model`, `body_type`, `fuel_type`, `year`, `price`, `status`, `photo`) VALUES
(1, 'gowsi', '8765432190', '2023-04-20', 'chennai', 'Cash On Delivery', 'TN 09', 'Honda', 'Honda Crosstour', 'Coupe', 'Fuel Type', '2022', '4-5 Lakhs', 'admapproved', '1680105134507.jpg'),
(2, 'jo', '8976543210', '2023-04-19', 'karaikudi', 'Online', 'TN 38', 'Toyota', 'Avalon', 'Coupe', 'Petrol', '2019', '4-5 Lakhs', 'sold', '1680105134415.jpg'),
(3, 'kani', '8765432190', '2023-04-01', 'kumbakonam', 'Cash On Delivery', 'TN 38', 'Maruti', 'Dzire', 'Coupe', 'Petrol', '2020', '7-8 Lakhs', 'New', '1680105134448.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `buytestdrive`
--

CREATE TABLE `buytestdrive` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buytestdrive`
--

INSERT INTO `buytestdrive` (`id`, `name`, `phone_no`, `date`, `time`, `status`) VALUES
(1, 'None', 'None', '2023-04-21', '17:18', 'New'),
(2, 'gowsi', '8765432190', '2023-03-30', '14:22', 'empapproved'),
(3, 'jo', '8976543210', '2023-04-06', '13:22', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `eforget`
--

CREATE TABLE `eforget` (
  `id` int(50) NOT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `upload_photo` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eforget`
--

INSERT INTO `eforget` (`id`, `id_number`, `name`, `email`, `destination`, `username`, `password`, `contact_no`, `upload_photo`, `status`) VALUES
(1, 'Emp550001', 'gowsi', 'gowsalyamurugesan@gmail.com', 'Sales Executive', '', '', '9876543210', 'a7.jpg', 'approved'),
(2, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', 'Emp550002', 'Emjo12', '9876543210', 'a7.jpg', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `empaddedcar`
--

CREATE TABLE `empaddedcar` (
  `id` int(50) NOT NULL,
  `id_no` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `transmission` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `mileage` varchar(50) DEFAULT NULL,
  `body_type` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `kilometer_driven` varchar(50) DEFAULT NULL,
  `car_owner` varchar(50) DEFAULT NULL,
  `fuel_type` varchar(50) DEFAULT NULL,
  `seating_type` varchar(50) DEFAULT NULL,
  `car1_photo` varchar(50) DEFAULT NULL,
  `car2_photo` varchar(50) DEFAULT NULL,
  `car3_photo` varchar(50) DEFAULT NULL,
  `car4_photo` varchar(50) DEFAULT NULL,
  `rc_book_photo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `empaddedcar`
--

INSERT INTO `empaddedcar` (`id`, `id_no`, `make`, `model`, `transmission`, `year`, `mileage`, `body_type`, `color`, `kilometer_driven`, `car_owner`, `fuel_type`, `seating_type`, `car1_photo`, `car2_photo`, `car3_photo`, `car4_photo`, `rc_book_photo`) VALUES
(1, 'tn5505', 'Audi', 'Q2', 'Automatic', '2020', 'Honda Jazz MT Diesel 27.3 kmpl', 'Sedan', 'Green', '2000-3000 km', '2st Owner', 'Diesel', '5', 'front-view.webp', 'rear-left.webp', 'front-left-side-47.webp', 'rear-view-119.webp', 'rcbook.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `empleaverequest`
--

CREATE TABLE `empleaverequest` (
  `id` int(50) NOT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `from_date` varchar(50) DEFAULT NULL,
  `to_date` varchar(50) DEFAULT NULL,
  `days` varchar(50) DEFAULT NULL,
  `reason_for_leave` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `empleaverequest`
--

INSERT INTO `empleaverequest` (`id`, `id_number`, `name`, `email`, `destination`, `from_date`, `to_date`, `days`, `reason_for_leave`, `status`) VALUES
(1, 'Emp550001', 'gowsi', 'gowsalyamurugesan@gmail.com', 'Sales Executive', 'None', 'None', '14', 'Vacation', 'reject'),
(2, 'Emp550001', 'gowsi', 'gowsalyamurugesan@gmail.com', 'Sales Executive', 'None', 'None', '-35', 'Vacation', 'approved'),
(3, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', 'None', 'None', '-35', 'Vacation', 'approved'),
(4, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', 'None', 'None', 'None', 'None', 'New'),
(5, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', 'None', 'None', 'None', 'None', 'reject'),
(6, 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'Reason For Leave', 'New'),
(7, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Quitting', 'New'),
(8, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Quitting', 'New'),
(9, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Quitting', 'New'),
(10, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Vacation', 'New'),
(11, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Vacation', 'New'),
(12, 'None', 'None', 'None', 'None', '2023-03-10', '2023-03-11', '-1', 'Vacation', 'New'),
(13, 'None', 'None', 'None', 'None', '2023-03-03', '2023-03-12', '-9', 'Vacation', 'New'),
(14, 'None', 'None', 'None', 'None', '2023-03-03', '2023-03-12', '-9', 'Vacation', 'New'),
(15, 'None', 'None', 'None', 'None', '2023-03-03', '2023-03-12', '-9', 'Vacation', 'New'),
(16, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', '2023-03-04', '2023-03-24', '-20', 'Quitting', 'New'),
(17, 'Emp550001', 'gowsi', 'gowsalyamurugesan@gmail.com', 'Sales Executive', '2023-03-29', '2023-03-11', '18', 'Quitting', 'approved'),
(18, 'Emp550002', 'jo', 'jo@gmail.com', 'Mechanical', '2023-03-12', '2023-03-10', '2', 'Sick', 'reject');

-- --------------------------------------------------------

--
-- Table structure for table `empregister`
--

CREATE TABLE `empregister` (
  `id` int(50) NOT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `date_of_birth` varchar(50) DEFAULT NULL,
  `date_of_joining` varchar(50) DEFAULT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `id_proof` varchar(50) DEFAULT NULL,
  `upload_id_proof` varchar(50) DEFAULT NULL,
  `upload_photo` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `salary` varchar(50) DEFAULT NULL,
  `qualification` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `empregister`
--

INSERT INTO `empregister` (`id`, `id_number`, `name`, `email`, `date_of_birth`, `date_of_joining`, `marital_status`, `destination`, `contact_no`, `phone_no`, `id_proof`, `upload_id_proof`, `upload_photo`, `gender`, `address`, `state`, `district`, `city`, `salary`, `qualification`, `username`, `password`, `status`) VALUES
(1, 'Emp550001', 'gowsi', 'gowsalyamurugesan@gmail.com', '2001-08-18', '2023-02-27', 'Unmarried', 'Sales Executive', '9876543210', '8765432190', 'Pan Card', 'bulb.png', 'e1.png', 'Female', 'kumbakonam', 'TamilNadu', 'Pudukkottai', 'Pudukkottai', '1,0000', 'Arts', 'Emp550001', 'Emgow18', 'Active'),
(2, 'Emp550002', 'jo', 'jo@gmail.com', '2023-03-12', '2023-03-08', 'Unmarried', 'Mechanical', '9876543210', '8976543210', 'Pan Card', 'admin.jpg', 'a7.jpg', 'Female', 'kumbakonam', 'TamilNadu', 'Thanjavur', 'Thanjavur', '1,0000', 'Science', 'Emp550002', 'Emjo12', 'Active'),
(4, 'Emp550003', 'pugal', 'pugal@gmail.com', '2001-05-05', '2023-03-16', 'Unmarried', 'Sales Executive', '9003858704', '9876543221', 'Aadhaar Card', '1676350396307.jpg', 'admin.jpg', 'Male', 'chennai', 'TamilNadu', 'Chennai', 'Chennai', '1,00000', 'Science', 'Emp550003', 'Empug05', 'Active'),
(5, 'Emp550005', 'siva', 'siva@gmail', '2023-03-05', '2023-03-05', 'Unmarried', 'Sales Executive', '9876543210', '8765422659', 'Pan Card', '1675663488176.png', 'e4.png', 'Male', 'coimbator', 'TamilNadu', 'Coimbatore', 'Coimbatore', '1,0000', 'Science', 'Emp550005', 'Empsiva', 'InActive');

-- --------------------------------------------------------

--
-- Table structure for table `salecarusers`
--

CREATE TABLE `salecarusers` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `current_location` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `km_driven` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `expect_price` varchar(50) DEFAULT NULL,
  `car_p1` varchar(50) DEFAULT NULL,
  `car_p2` varchar(50) DEFAULT NULL,
  `car_p3` varchar(50) DEFAULT NULL,
  `rc_book` varchar(50) DEFAULT NULL,
  `insurance` varchar(50) DEFAULT NULL,
  `fuel` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salecarusers`
--

INSERT INTO `salecarusers` (`id`, `name`, `phone_no`, `city`, `current_location`, `brand`, `model`, `year`, `km_driven`, `color`, `expect_price`, `car_p1`, `car_p2`, `car_p3`, `rc_book`, `insurance`, `fuel`, `status`) VALUES
(1, 'jo', '8976543210', 'Kumbakonam', 'kumbakonam', 'Honda', 'Amaze', '2022', '11,081', 'gray', '7,00,000', '1680105134400.jpg', '1680105134388.jpg', '1680105134373.jpg', 'regimg.jpg', '1675663488176.png', 'petrol', 'sold'),
(2, 'gowsi', '8765432190', 'Kumbakonam', 'Trichy', 'Maruti', 'Amaze', '2020', '11,000', 'Blue', '500000', '1680105134474.jpg', '1680105134465.jpg', '1680105134448.jpg', 'regimg.jpg', 'regimg.jpg', 'petrol', 'donesale'),
(3, 'kani', '8765432190', 'Ambattur', 'pudukkottai', 'Toyota', 'Amaze', '2021', '10,000', 'white', '300000', '1680105134507.jpg', '1680105134499.jpg', '1680105134491.jpg', 'regimg.jpg', 'regimg.jpg', 'petrol', 'sold'),
(4, 'kani', '8765432190', 'Ambattur', 'karaikudi', 'Toyota', 'Amaze', '2020', '10,000', 'white', '5,00,000', '1680105134499.jpg', '1680105134491.jpg', '1680105134482.jpg', 'rcbook.jpg', 'rcbook.jpg', 'petrol', 'admapproved');

-- --------------------------------------------------------

--
-- Table structure for table `saletestdrive`
--

CREATE TABLE `saletestdrive` (
  `id` int(50) NOT NULL,
  `datee` varchar(50) DEFAULT NULL,
  `timee` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saletestdrive`
--

INSERT INTO `saletestdrive` (`id`, `datee`, `timee`, `status`) VALUES
(1, '2023-04-12', '09:44', 'Done'),
(2, '2023-04-26', '21:56', 'Done'),
(3, '2023-04-10', '22:51', 'empapproved'),
(4, '2023-04-14', '19:05', 'empapproved');

-- --------------------------------------------------------

--
-- Table structure for table `uregister`
--

CREATE TABLE `uregister` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `date_of_birth` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `id_proof` varchar(50) DEFAULT NULL,
  `upload_id_proof` varchar(100) DEFAULT NULL,
  `upload_photo` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `uregister`
--

INSERT INTO `uregister` (`id`, `name`, `email`, `date_of_birth`, `username`, `password`, `contact_no`, `phone_no`, `id_proof`, `upload_id_proof`, `upload_photo`, `gender`, `address`, `state`, `district`, `city`) VALUES
(1, 'gowsi', 'gowsalyamurugesan@gmail.com', '2001-08-18', 'gowsalyamurugesan@gmail.com', 'gowsi123', '9876543210', '8765432190', 'Aadhaar Card', 'g27.jpg', 'a7.jpg', 'Female', 'kumbakonam', 'TamilNadu', 'Thanjavur', 'Kumbakonam'),
(2, 'jo', 'jo@gmail.com', '2023-02-12', 'jo@gmail.com', 'jo', '9876543210', '8976543210', 'Pan Card', 'e4.png', 'e4.png', 'Female', 'kumbakonam', 'TamilNadu', 'Thanjavur', 'Kumbakonam'),
(3, 'kani', 'kani@gmail.com', '2023-04-29', 'kani@gmail.com', 'kani', '9876543210', '8765432190', 'Pan Card', 'regimg.jpg', 'admin.jpg', 'Female', 'chennai', 'TamilNadu', 'Chennai', 'Ambattur'),
(4, 'suba', 'suba@gmail.com', '2023-04-12', 'suba@gmail.com', 'suba', '7890654321', '9876543210', 'Voter Id', 'regimg.jpg', 'e1.png', 'Female', 'Thanjavur', 'TamilNadu', 'Thanjavur', 'Thanjavur'),
(5, 'gowtham', 'gowtham@gmail.com', '2023-04-15', 'gowtham@gmail.com', 'gowtham', '8907654321', '7890654321', 'Aadhaar Card', 'regimg.jpg', 'e4.png', 'Male', 'pudukkottai', 'TamilNadu', 'Pudukkottai', 'Pudukkottai');

-- --------------------------------------------------------

--
-- Table structure for table `userforget`
--

CREATE TABLE `userforget` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `upload_photo` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userforget`
--

INSERT INTO `userforget` (`id`, `name`, `email`, `username`, `password`, `contact_no`, `upload_photo`, `status`) VALUES
(1, 'gowsi', 'gowsalyamurugesan@gmail.com', 'gowsalyamurugesan@gmail.com', 'gowsi', '9876543210', 'a7.jpg', 'New'),
(2, 'jo', 'jo@gmail.com', 'jo@gmail.com', 'jo', '9876543210', 'e4.png', 'reject');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcars`
--
ALTER TABLE `addcars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buycaruser`
--
ALTER TABLE `buycaruser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buytestdrive`
--
ALTER TABLE `buytestdrive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eforget`
--
ALTER TABLE `eforget`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empaddedcar`
--
ALTER TABLE `empaddedcar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empleaverequest`
--
ALTER TABLE `empleaverequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empregister`
--
ALTER TABLE `empregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salecarusers`
--
ALTER TABLE `salecarusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saletestdrive`
--
ALTER TABLE `saletestdrive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uregister`
--
ALTER TABLE `uregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userforget`
--
ALTER TABLE `userforget`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcars`
--
ALTER TABLE `addcars`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `buycaruser`
--
ALTER TABLE `buycaruser`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `buytestdrive`
--
ALTER TABLE `buytestdrive`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eforget`
--
ALTER TABLE `eforget`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `empaddedcar`
--
ALTER TABLE `empaddedcar`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `empleaverequest`
--
ALTER TABLE `empleaverequest`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `empregister`
--
ALTER TABLE `empregister`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `salecarusers`
--
ALTER TABLE `salecarusers`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `saletestdrive`
--
ALTER TABLE `saletestdrive`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `uregister`
--
ALTER TABLE `uregister`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userforget`
--
ALTER TABLE `userforget`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
