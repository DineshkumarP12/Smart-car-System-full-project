#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")


print("""<!DOCTYPE html>
<html lang="en">

<head>
    <title>empregi</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./media/logoonly.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

    <style>
        .nav-side-menu {
            overflow: auto;
            font-family: verdana;
            font-size: 15 px;
            font-weight: 200;
            background-image: linear-gradient(rgb(105, 3, 57), rgb(188, 13, 106), rgb(234, 96, 170));
            position: fixed;
            top: 0px;
            /* width: 350px; */
            width: 280px;
            height: 100%;
            color: #e1ffff;

        }

        .nav-side-menu .brand {
            line-height: 50px;
            display: block;
            text-align: center;
            font-size: 14px;
            padding: 15px;
        }

        .nav-side-menu .toggle-btn {
            display: none;
        }

        .nav-side-menu ul,
        .nav-side-menu li {
            list-style: none;
            padding: 0px;
            margin: 0px;
            line-height: 35px;
            cursor: pointer;

        }

        .nav-side-menu ul :not(collapsed) .arrow:before,
        .nav-side-menu li :not(collapsed) .arrow:before {
            font-family: FontAwesome;
            content: "\f078";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
            /* float: right; */
        }

        .nav-side-menu ul .active,
        .nav-side-menu li .active {
            border-left: 3px solid #d19b3d;
            background-color: #7e4eee;
            /* background-color: darkgray; */
        }

        /* .nav-side-menu ul .sub-menu li.active,
        .nav-side-menu li .sub-menu li.active {
            background-color: #ecc9ed;
            color: #090909;
        } */

        /* .nav-side-menu ul .sub-menu li.active a,
        .nav-side-menu li .sub-menu li.active a {
            color: #050505;
        } */

        .nav-side-menu ul .sub-menu li,
        .nav-side-menu li .sub-menu li {
            background-color: rgb(18, 82, 107);
            border: none;
            line-height: 28px;
            border-bottom: 1px solid #23282e;
            margin-left: 0px;
        }

        .nav-side-menu ul .sub-menu li:hover,
        .nav-side-menu li .sub-menu li:hover {
            background-color: rgb(153, 5, 5);
        }

        .nav-side-menu ul .sub-menu li:before,
        .nav-side-menu li .sub-menu li:before {
            font-family: FontAwesome;
            content: "\f105";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
        }

        .nav-side-menu li {
            padding-left: 0px;
            border-left: 3px solid #2e353d;
            border-bottom: 1px solid #23282e;
        }

        .nav-side-menu li a {
            text-decoration: none;
            color: #e1ffff;
        }

        .nav-side-menu li a i {
            padding-left: 10px;
            width: 20px;
            padding-right: 20px;
        }

        .nav-side-menu li:hover {
            border-left: 3px solid #d19b3d;
            background-color: rgb(208, 63, 140);
            color: white;
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        @media (max-width: 767px) {
            .nav-side-menu {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }

            .nav-side-menu .toggle-btn {
                display: block;
                cursor: pointer;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 10 !important;
                padding: 3px;
                background-color: #ffffff;
                color: black;
                width: 40px;
                text-align: center;
            }

            .brand {
                padding-left: 5px;
                height: 100px;
            }
        }

        @media (min-width: 767px) {
            .nav-side-menu .menu-list .menu-content {
                display: block;
            }
        }

        body {
            margin: 0px;
            padding: 0px;
        }

        hr {
            color: #23282e;
            width: 120px;
        }

        .form-control,
        .col-md-6 {
            border-radius: 20px;
        }

        .btoggle {
            margin-left: 260px;
            margin-top: -30px;
        }

        form {
            width: 300px;
            height: 300px;
        }

        .a {
            color: black;
            font-size: 15px;
            margin-left: -180px;
        }

        .aa {
            color: black;
            font-size: 15px;
        }

        #color {
            opacity: 0.9;
            background-color: ghostwhite;

        }

        form {
            width: 100%;
        }
    </style>
</head>

<body>
    <div class="nav-side-menu">
        <div class="brand">
            <h1>Admin Page</h1>
        </div>
        <hr>
        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">

                <li data-toggle="collapse" data-target="#products" class="collapsed">
                    <a href="#"><i class="fa fa-user fa-lg"></i>Employee Details <span class="arrow"></span></a>
                </li>
               <ul class="sub-menu collapse" id="products">
                    <li class="active"><a href="./Adm_Emp_register.py">Add Employee Details</a></li>
                    <li><a href="./Adm_emp_view.py">View Employee Details</a></li>
                    <li><a href="./Adm_emp_leave_report.py">Leave Report</a></li>
                    <li><a href="./Adm_emp_leave_request.py">Leave Request</a></li>
                    <li><a href="./Adm_emp_password_request.py">Password Request</a></li>
                </ul>


                <li data-toggle="collapse" data-target="#service" class="collapsed">
                    <a href="#"><i class="fa fa-user fa-lg"></i> Buy User Request<span class="arrow"></span></a>
                </li>
               <ul class="sub-menu collapse" id="service">
                    <li><a href="./Adm_new_user_buy.py">New User</a></li>
                    <li><a href="./Adm_buy_status.py">buy complete process</a></li>
                    <li><a href="./Adm_user_password_request.py">Password Request</a></li>


                </ul>
                <li data-toggle="collapse" data-target="#service2" class="collapsed">
                    <a href="#"><i class="fa fa-user fa-lg"></i> Sale User Request<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="service2">
                    <li><a href="./Adm_sale_user.py">New User</a></li>
                     <li><a href="./Adm_sale_status.py">sale complete process</a></li>
                    <li><a href="./Adm_user_password_request.py">Password Request</a></li>


                </ul>


                <li data-toggle="collapse" data-target="#new" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> Cars<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                    <li><a href="./Adm_add_Car.py">Add Cars</a></li>
                    <li><a href="./Adm_Car_view.py">Existing Cars</a></li>
                      <li><a href="./Adm_new_cars.py">New Cars</a></li>
                       
                </ul>
                <li>
                    <a href="./Index_page.py">
                        <i class="fa fa-sign-out fa-lg"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    </body>

</html>""")
import pymysql
import cgi, cgitb,os

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
form=cgi.FieldStorage()
pid = form.getvalue("id")
q2= """select * from empregister where id=%s """ %(pid)
cur.execute(q2)
# q="""select * from  empregister"""
# cur.execute(q)
res=cur.fetchall()
# print(res)
for i in res:
    print("""<form action="" method="post" enctype="multipart/form-data">

        <div class="content">
            <div class="col-md-3"></div>
            <div class="form">
                <center>
                    <h1
                        style="text-shadow: 2px 3px 2px aqua;font-family:fantasy;color: rgb(13, 108, 108);letter-spacing: 1px;">
                        <i class="fa fa-user fa-lg"></i> Update Employee

                    </h1>
                </center>
                <br>
                <div class="form-content">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="ID Number" name="iid" value="%s" readonly>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Name" required value="%s" name="name">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email Id" required id="email"
                                    onchange="changeuser()" autocomplete="off" value="%s" name="email">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" onfocus="(this.type='date')"
                                    placeholder="Date-Of-Birth" value="%s" name="dob">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Date-Of-Joining"
                                    onfocus="(this.type='date')" value="%s" name="doj">
                            </div>
                            <div class="form-group">
                                 <input type="text" class="form-control" placeholder="Marital Status" value="%s" name="ms">
                            </div>
                            <div class="form-group">
                             <input type="text" class="form-control" placeholder="Destination" value="%s" name="des">
                               </div>

                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Contact Number" required
                                    value="%s" name="cn">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Phone Number" value="%s" name="phone">
                            </div>
                           
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-4">
                            
                            <div class="form-group">
                             <input type="text" class="form-control" placeholder="ID Proof" value="%s" name="ip">
                            
                            </div>
                            <div class="form-group">
                            <input type="text" placeholder="Gender" class="form-control" required value="%s" name="gen">
                                
                            </div>

                            <div class="form-group">
                                <input type="text" placeholder="Address" class="form-control" required value="%s" name="add">
                                <br>
                                <input type="text" class="form-control" placeholder="Select State" value="%s" name="ss"  >
                               <br>
                            <input type="text" class="form-control" placeholder="Select District" value="%s" name="sd">
                               
                               <br>
                                <input type="text" class="form-control" placeholder="Select City" value="%s" name="sc">
                                
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Salary" value="%s" name="salary">
                            </div>
                            <div class="form-group">
                            <input type="text" class="form-control" placeholder="Qualification" value="%s" name="qua">
                                

                            </div>
                             <div class="form-group">
                               <input type="text" class="form-control" placeholder="Active" value="%s" name="active">
                            </div><br>
                            <center>

                                <input type="submit" class="btn-success" style="font-size: 20px;" value="Update" name="update">

                            </center><br>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </form>"""%(i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[13],i[14],i[15],i[16],i[17],i[18],i[19],i[22]))


# print(id1,name,email,dob,ms,des,cn,phone,ip,gen,add,ss,sd,sc,salary,qua)

update = form.getvalue("update")
if update != None:
    if len(form) != 0:
        id1 = form.getvalue("iid")
        name = form.getvalue("name")
        email = form.getvalue("email")
        dob = form.getvalue("dob")
        doj = form.getvalue("doj")
        ms = form.getvalue("ms")
        des = form.getvalue("des")
        cn = form.getvalue("cn")
        phone = form.getvalue("phone")
        ip = form.getvalue("ip")
        gen = form.getvalue("gen")
        add = form.getvalue("add")
        ss = form.getvalue("ss")
        sd = form.getvalue("sd")
        sc = form.getvalue("sc")
        salary = form.getvalue("salary")
        qua = form.getvalue("qua")
        active=form.getvalue("active")
        # photo1 = form['upload']
        # photo2 = form['up']
        # if photo1.filename:
        #
        #     fn=os.path.basename(photo1.filename)
        #     fn2=os.path.basename(photo2.filename)
        #     open("empphoto/"+fn,"wb").write(photo1.file.read())
        #     open("empphoto/"+fn2,"wb").write(photo2.file.read())

        q="""update empregister set name='%s',email='%s',date_of_birth='%s',date_of_joining='%s',marital_status='%s',destination='%s',contact_no='%s',phone_no='%s',id_proof='%s',gender='%s',address='%s',state='%s',district='%s',city='%s',salary='%s',qualification='%s', status='%s' where id='%s' """%(name,email,dob,doj,ms,des,cn,phone,ip,gen,add,ss,sd,sc,salary,qua,active,pid)
        cur.execute(q)
        conn.commit()
        print("""<script>alert("update successfully");</script>""")
conn.close()