#!C:/Users/Admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")

import pymysql
import cgi, cgitb

cgitb.enable()
conn = pymysql.connect(host="localhost", user="root", password="", database="smartcar")
cur = conn.cursor()
# q="""create table empLeaveRequest(id int(50) Auto_increment primary key,id_number varchar(50),name varchar(50),email varchar(50),destination varchar(50),from_date varchar(50),to_date varchar(50),days varchar(50),reason_for_leave varchar(50))"""
# cur.execute(q)
f = cgi.FieldStorage()
idvalue = f.getvalue("id")
print("""<!DOCTYPE html>
<html lang="en">

<head>
    <title>emppage</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="./media/logoonly.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

    <style>
        .nav-side-menu {
            overflow: auto;
            font-family: verdana;
            font-size: 15 px;
            font-weight: 200;
            background-image: linear-gradient(rgb(120, 33, 4), rgb(253, 70, 9), rgb(251, 108, 60));
            position: fixed;
            top: 0px;
            width: 280px;
            height: 100%;
            color: #e1ffff;

        }

        .nav-side-menu .brand {
            line-height: 50px;
            display: block;
            text-align: center;
            font-size: 14px;
            padding: 15px;
        }

        .nav-side-menu .toggle-btn {
            display: none;
        }

        .nav-side-menu ul,
        .nav-side-menu li {
            list-style: none;
            padding: 0px;
            margin: 0px;
            line-height: 35px;
            cursor: pointer;

        }

        .nav-side-menu ul :not(collapsed) .arrow:before,
        .nav-side-menu li :not(collapsed) .arrow:before {
            font-family: FontAwesome;
            content: "\f078";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
            /* float: right; */
        }

        .nav-side-menu ul .active,
        .nav-side-menu li .active {
            border-left: 3px solid #d19b3d;

        }

        .nav-side-menu ul .sub-menu li,
        .nav-side-menu li .sub-menu li {
            background-color: rgb(130, 35, 170);
            border: none;
            line-height: 28px;
            border-bottom: 1px solid #23282e;
            margin-left: 0px;
        }

        .nav-side-menu ul .sub-menu li:hover,
        .nav-side-menu li .sub-menu li:hover {
            background-color: deeppink;
        }

        .nav-side-menu ul .sub-menu li:before,
        .nav-side-menu li .sub-menu li:before {
            font-family: FontAwesome;
            content: "\f105";
            display: inline-block;
            padding-left: 10px;
            padding-right: 10px;
            vertical-align: middle;
        }

        .nav-side-menu li {
            padding-left: 0px;
            border-left: 3px solid #2e353d;
            border-bottom: 1px solid #23282e;
        }

        .nav-side-menu li a {
            text-decoration: none;
            color: #e1ffff;
        }

        .nav-side-menu li a i {
            padding-left: 10px;
            width: 20px;
            padding-right: 20px;
        }

        .nav-side-menu li:hover {
            border-left: 3px solid #d19b3d;
            background-color: deeppink;
            color: white;
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        @media (max-width: 767px) {
            .nav-side-menu {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }

            .nav-side-menu .toggle-btn {
                display: block;
                cursor: pointer;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 10 !important;
                padding: 3px;
                background-color: #ffffff;
                color: black;
                width: 40px;
                text-align: center;
            }

            .brand {
                padding-left: 5px;
                height: 100px;
            }
        }

        @media (min-width: 767px) {
            .nav-side-menu .menu-list .menu-content {
                display: block;
            }
        }

        body {
            margin: 0px;
            padding: 0px;
        }

        hr {
            color: #23282e;
            width: 120px;
        }
        .card {
            border: 1px;
            background-color: white;
            border-radius: 15px 15px 15px 15px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            height: 500px;
            width: 460px;

        }

        .form-control {
            width: 300px;
        }

        .h1 {
            text-shadow: 2px 3px 2px pink;
            color: rgb(243, 10, 134);
            font-family: fantasy;
            margin-left: 30px;
        }

        .hr {
            width: 460px;

        }

        #sub {
            width: 100px;
            height: 40px;
        }

        .h3 {
            margin-left: -180px;
        }
    </style>
    </style>
</head>

<body>
    <div class="nav-side-menu">
        <div class="brand">
            <h3>Employee Page</h3>
            <h1>mechanical</h1>
        </div>
        <hr>
        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

        <div class="menu-list">

            <ul id="menu-content" class="menu-content collapse out">""")
print("""
                <li>
                    <a href="./Emp2_profile.py?id=%s"><i class="fa fa-user fa-lg"></i> Profile
                    </a>
                </li>"""%idvalue)
print("""
                <li data-toggle="collapse" data-target="#new" class="collapsed">
                    <a href="#"><i class="fa fa-car fa-lg"></i> User Request<span class="arrow"></span></a>
                </li>
                <ul class="sub-menu collapse" id="new">
                    <li><a href="./Emp2_user_buy.py?id=%s">Buy cars</a></li>
                    <li><a href="./Emp2_complete_buy.py?id=%s">complete buy cars</a></li>
                    <li><a href="./Emp2_user_sale.py?id=%s">Sales cars</a></li>
                    <li><a href="./Emp2_complete_sale.py?id=%s">complete Sales cars</a></li>

                </ul>"""%(idvalue,idvalue,idvalue,idvalue))
print("""
                <li data-toggle="collapse" data-target="#service" class="collapsed">
                    <a href="./Emp2_leave_request.py?id=%s"><i class="fa fa-reply fa-lg"></i> Leave Request</a>
                </li>
                """%idvalue)
print("""
                <li>
                    <a href="./Index_page.py">
                        <i class="fa fa-sign-out fa-lg"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
<div class="container">
       
    </div><br>
    <script type="text/javascript">
        function GetDays() {
            var dp = new Date(document.getElementById("drop_date").value);
            var pd = new Date(document.getElementById("pick_date").value);
            return parseInt((pd - dp) / (24 * 3600 * 1000));
        }

        function cal() {
            if (document.getElementById("drop_date")) {
                document.getElementById("numdays2").value = GetDays();
            }
        }

    </script>
</body>

</html>""")

q4 = """select * from empregister where id='%s' """ %(idvalue)
cur.execute(q4)
res = cur.fetchall()
for i in res:
    print(""" <form><br><br><br>
            <div class="row">

                <div class="col-md-4"></div>
                <div class="col-md-3">
                    <div class="card">
                        <br>

                        <center class="cen">
                            <h1 class="h1">Request for Leave</h1>
                            <br>
                            <hr class="hr">

                            <h3 class="h3"> Details of Leave</h3>
                            <br>

                            <div class="form-group" id="pickup_date">
                                <input type="text" class="form-control" placeholder="From Date"
                                    onfocus="(this.type='date')" id="pick_date" name="pickup_date" onchange="cal()" >
                            </div>
                            <div class="form-group" id="dropoff_date">
                                <input type="text" class="form-control" placeholder="To Date"
                                    onfocus="(this.type='date')" id="drop_date" name="dropoff_date" onchange="cal()">
                            </div>
                            <div class="form-group" id="numdays">

                                <input type="text" placeholder="Days" class="form-control" id="numdays2" name="numdays">
                            </div>

                            <div class="form-group">
                                <select class="form-control" name="leave">
                                    <option>Reason For Leave</option>
                                    <option>Vacation</option>
                                    <option>Sick</option>
                                    <option>Quitting</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <input type="text" class="form-control hh"  placeholder="idnumber" value="%s" name="id1" style="display:none;">
<input type="text" class="form-control hh"  placeholder="name"  value="%s" name="Name" style="display:none;">
<input type="text" class="form-control hh"  placeholder="mail" value="%s" name="email4" style="display:none;">
<input type="text" class="form-control hh" placeholder="des" value="%s" name="des" style="display:none;">
                            <input type="submit" name="leavereq" class="btn-success" id="sub" >

                        </center>
                    </div>
                </div>
        </form>

"""%(i[1],i[2],i[3],i[7]))


Submitreq = f.getvalue("leavereq")
if Submitreq != None:
    id1 = f.getvalue("id1")
    Name = f.getvalue("Name")
    email4 = f.getvalue("email4")
    des = f.getvalue("des")
    print(email4)
    status = "New"
    from1 = f.getvalue("pickup_date")
    todate = f.getvalue("dropoff_date")
    days = f.getvalue("numdays")
    leave = f.getvalue("leave")
    q="""insert into empleaverequest(id_number,name,email,destination,from_date,to_date,days,reason_for_leave,status)values('%s','%s','%s','%s','%s','%s','%s','%s','%s')""" %(id1,Name,email4,des,from1,todate,days,leave,status)
    cur.execute(q)
    conn.commit()
    print("""<script>alert("request successful");</script>""")
conn.close()